import SwiftUI
struct ContentView: View {
    @State private var textInput: String = "ようこそ"
    var body: some View {
        
        HStack {
            Text("Oboegaki")
                .bold()
            
            Button(action: {
                NSApp.terminate(self)
            }) {
                Image(systemName: "power.circle.fill")
            }
            .buttonStyle(PlainButtonStyle())
            //電源ボタン
        }
        .padding(.top, 8)
        
        Divider() //仕切り
        
        TextEditor(text: $textInput)
                        .padding(.vertical, 4)
                        .scrollContentBackground(.hidden)
                        .background(.thinMaterial)
                        .onAppear { load() }
                                    .onChange(of: textInput) { save() }//入力欄
        
        Divider() //仕切り
        
            Button("クリア") {
                textInput = ""
            }
            Text("cmd+Zは効きません")
                    .font(.caption)
                    .foregroundStyle(.gray)
        }
    
    private var url: URL {
           let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
           try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
           return dir.appendingPathComponent("text.txt")
       }

       private func save() {
           print("保存場所:", url.path)
           try? textInput.write(to: url, atomically: true, encoding: .utf8)
       }

       private func load() {
           textInput = (try? String(contentsOf: url)) ?? textInput
       }
    }//読み書き



#Preview {
    ContentView()
}
