import SwiftUI

@main
struct oboegakiApp: App {
    var body: some Scene {
        MenuBarExtra(
            "MenuBar Example",
            systemImage: "pano.fill"
        ) {
            ContentView()
                .frame(width: 300, height: 180)
        }
        .menuBarExtraStyle(.window)
    }
}
