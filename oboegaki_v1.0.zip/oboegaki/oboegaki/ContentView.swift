import SwiftUI
struct ContentView: View {
    @State private var textInput: String = "ようこそ"
    var body: some View {
        
        HStack {
            Text("Oboegaki")
                .bold()
            
            Button(action: {
                NSApp.terminate(self)
            }) {
                Image(systemName: "power.circle.fill")
            }
            .buttonStyle(PlainButtonStyle())
            //電源ボタン
        }
        .padding(.top, 8)
        
        Divider() //仕切り
        
        TextEditor(text: $textInput)
                        .padding(.vertical, 4)
                        .scrollContentBackground(.hidden)
                        .background(.thinMaterial)//入力欄
        
        Divider() //仕切り
        
            Button("クリア") {
                textInput = ""
            }
            Text("cmd+Zは効きません")
                    .font(.caption)
                    .foregroundStyle(.gray)
        }
    }

#Preview {
    ContentView()
}
